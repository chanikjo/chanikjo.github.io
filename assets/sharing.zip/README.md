# PUE data release

Policy Uptake Elasticity (PUE) measures the degree to which an agency
revises a proposed rule in the direction of the public comments it received.
Two files accompany "Does Government Listen to the Public? Measuring
Democratic Responsiveness and Its Impact on Business Performance" (Ahn, Jo,
Song and Yang). Both are comma-separated text with a header row.

## pue_docket.csv (5,103 rows, one per rulemaking)

| column | description |
|---|---|
| rule_id | identifier used in the paper (final-rule year and sequence) |
| docket_id | Regulations.gov docket id, or SEC file number for SEC rules |
| agency_id, agency_name | issuing agency |
| fr_document_proposed, fr_document_final | Federal Register document numbers of the proposed and final rules |
| date_final | publication date of the final rule |
| pue_all | PUE computed on all comments |
| pue_ind | PUE computed on comments by individuals |
| pue_corp | PUE computed on comments by business entities and trade associations |
| reg_stringency | change in regulatory stringency from the existing to the final text, averaged over the rule's sections (-1 less stringent, 0 no change, 1 more stringent) |
| n_comments_all, n_comments_ind, n_comments_corp | number of comment clusters (near-duplicate campaign comments count once) |

PUE is the product of the rule's revision direction (share of sections made
more stringent minus share made less stringent between the proposed and final
text) and the direction advocated by the commenter group (weighted mean of
comment stringency positions). A positive value means the final rule moved
toward what the group asked for; a negative value means it moved against it.
pue_ind and pue_corp are missing for rulemakings without comments from that
group. The sample is every rulemaking with a proposed and a final rule
published 2008-2024 for which regulatory text and comments could be paired.

## pue_firm_year.csv (83,331 rows, one per firm and fiscal year)

| column | description |
|---|---|
| gvkey | Compustat firm identifier |
| fyear | fiscal year, 2008-2024 |
| pue_corp | firm-year PUE from corporate and trade-association comments: sum over the rules applicable to the firm in that year of the rule's pue_corp, weighted by 1 + log(number of comment clusters on the rule) |
| pue_ind | the same aggregation of pue_ind |
| reg_stringency | the same aggregation of reg_stringency, paired with pue_corp |
| reg_stringency_ind | the same, on the rules entering pue_ind |
| n_rules_applicable | number of rules applicable to the firm in that year |

A rule is applicable to a firm when the firm's 10-K business description
(Item 1) and the rule's abstract are classified as related. The file covers
every firm-year with at least one applicable rule; the paper's regressions
use the subset with common shares on NYSE, AMEX or Nasdaq, positive book
equity and sales, and non-missing outcomes and controls (37,003 firm-years).

## Citation

Ahn, Changhyun, Chanik Jo, Camilla (Eunyoung) Song, and Joonwoo Yang.
"Does Government Listen to the Public? Measuring Democratic Responsiveness
and Its Impact on Business Performance." Management Science, forthcoming.

Release date: 2026-09-13.
